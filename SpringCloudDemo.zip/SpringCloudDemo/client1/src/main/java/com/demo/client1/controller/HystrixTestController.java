package com.demo.client1.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HystrixTestController {
    @PostMapping("/hystrixGetMessage")
    public String hystrixGetMessage(@RequestBody String message){
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return "client1 处理信息：" + message + "（client1 已处理）";
    }
}
