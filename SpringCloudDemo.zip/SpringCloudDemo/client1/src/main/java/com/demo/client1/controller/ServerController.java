package com.demo.client1.controller;

import com.demo.client1.entity.User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ServerController {
    @GetMapping("/userInfo")
    public User getUserInfo() {
        User user = new User();
        user.setName("小明");
        user.setAge(18);
        return user;
    }
}
