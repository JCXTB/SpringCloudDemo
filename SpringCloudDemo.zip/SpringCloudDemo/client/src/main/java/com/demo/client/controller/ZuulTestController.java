package com.demo.client.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/zuul")
public class ZuulTestController {

    @GetMapping("/getMessage")
    public String getMessage(HttpServletRequest httpServletRequest){
        return "这里是 Client 返回的信息";
    }
}
