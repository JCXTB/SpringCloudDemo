package com.demo.client2.controller;


import com.demo.client2.client.client1.client.UserClient;
import com.demo.client2.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {
    @Autowired
    private UserClient userClient;

    @GetMapping("/feignGetUserInfo")
    public User feignMessage() {
        return userClient.getUserInfo();
    }
}

