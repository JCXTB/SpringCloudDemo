package com.demo.client2.client.client1.client;

import com.demo.client2.entity.User;
import org.springframework.web.bind.annotation.GetMapping;

//@Component
//@FeignClient(name = "CLIENT1")
public interface UserClient {

    @GetMapping("/userInfo")
    User getUserInfo();
}
