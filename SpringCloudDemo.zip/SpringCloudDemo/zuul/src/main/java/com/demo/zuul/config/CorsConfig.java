package com.demo.zuul.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import java.util.Arrays;

@Configuration
public class CorsConfig {
    @Bean
    public CorsFilter corsFilter(){
        final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        final CorsConfiguration config = new CorsConfiguration();

        config.setAllowCredentials(true);   //是否支持 Cookie 跨域
        config.setAllowedOrigins(Arrays.asList("*"));   //原始域 例如：http:www.a.com
        config.setAllowedHeaders(Arrays.asList("*"));   //允许的敏感头
        config.setAllowedMethods(Arrays.asList("*"));   //允许的请求方式 GET POST ...
        config.setMaxAge(300L);                         //缓存时间，时间内相同跨域请求不再检查

        source.registerCorsConfiguration("/**", config);

        return new CorsFilter(source);
    }
}
