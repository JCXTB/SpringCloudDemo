package com.demo.zuul.exception;

public class RateLimiterException extends RuntimeException{
}
